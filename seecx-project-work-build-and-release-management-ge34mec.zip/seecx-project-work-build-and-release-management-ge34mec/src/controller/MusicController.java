package controller;

import java.io.InputStream;

public class MusicController {

	/* From stackoverflow, we'll get back to these later */
    /*private AudioPlayer MGP = AudioPlayer.player;
    private AudioStream BGM;
    private AudioData MD;*/
    
    private InputStream gameMusic; // = new FileInputStream("gamemusic.wav");
    private InputStream crashSound; // = new FileInputStream("gamemusic.wav");

    public void playGameMusic(){
    	//TODO
    }
    
    public void pauseGameMusic(){
    	//TODO
    }
    
    public void playcrashSound(){
    	//TODO
    }

}
